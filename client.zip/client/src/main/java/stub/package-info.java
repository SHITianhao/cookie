@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.tcf.polytech.unice.fr/")
package stub;
